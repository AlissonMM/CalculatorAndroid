package br.edu.fatec.calculatorandroid;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.view.View;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    private EditText edtFirst;
    private EditText edtSecond;
    private Button btnSum;
    private Button btnSub;
    private Button btnMul;
    private Button btnDiv;
    private Button btnQuit;
    private TextView txtResult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        edtFirst = findViewById(R.id.edtFirst);
        edtSecond = findViewById(R.id.edtSecond);
        btnSum = findViewById(R.id.btnSum);
        btnSub = findViewById(R.id.btnSub);
        btnMul = findViewById(R.id.btnMul);
        btnDiv = findViewById(R.id.btnDiv);
        btnQuit = findViewById(R.id.btnQuit);
        txtResult = findViewById(R.id.txtResult);



    }
    public void Sum(View view){
        float n1 = Float.parseFloat(edtFirst.getText().toString());
        float n2 = Float.parseFloat(edtSecond.getText().toString());

        float result = n1 + n2;

        String resultString = String.valueOf(result);

        txtResult.setText(resultString);
    }

    public void Subtract(View view){
        float n1 = Float.parseFloat(edtFirst.getText().toString());
        float n2 = Float.parseFloat(edtSecond.getText().toString());

        float result = n1 - n2;

        String resultString = String.valueOf(result);

        txtResult.setText(resultString);
    }
    public void Multiply(View view){
        float n1 = Float.parseFloat(edtFirst.getText().toString());
        float n2 = Float.parseFloat(edtSecond.getText().toString());

        float result = n1 * n2;

        String resultString = String.valueOf(result);

        txtResult.setText(resultString);
    }

    public void Divide(View view){
        float n1 = Float.parseFloat(edtFirst.getText().toString());
        float n2 = Float.parseFloat(edtSecond.getText().toString());

        float result = n1 / n2;

        String resultString = String.valueOf(result);

        txtResult.setText(resultString);
    }

    public void Quit(View view){
        finish();
    }
}